@echo off
setlocal
cd /d "%~dp0"
where cl >nul 2>nul
if errorlevel 1 (
  echo Run this file from an x64 Native Tools Command Prompt for VS 2022.
  exit /b 1
)
if not exist build mkdir build
cl /nologo /utf-8 /O2 /MT /W4 /WX /EHsc /std:c++17 /LD /Fe:..\CodeTaskbarLabels-1.0.dll labels.cpp /Fo:build\labels.obj /link /DYNAMICBASE /NXCOMPAT /IMPLIB:build\labels.lib
if errorlevel 1 exit /b 1
cl /nologo /utf-8 /O2 /MT /W4 /WX /EHsc /std:c++17 /Fe:..\CodeTaskbar.exe controller.cpp /Fo:build\controller.obj /link /SUBSYSTEM:WINDOWS /DYNAMICBASE /NXCOMPAT
exit /b %errorlevel%
