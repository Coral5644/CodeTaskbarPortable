@echo off
start "" /wait "%~dp0CodeTaskbar.exe" --status
if errorlevel 1 (
  echo The tool is not running. Start CodeTaskbar.exe first.
  pause
  exit /b 1
)
start "" notepad.exe "%~dp0status.txt"
